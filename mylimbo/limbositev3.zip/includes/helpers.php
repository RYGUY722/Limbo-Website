<?php
#Modified by Ryan Sheffler 11/12/2018
$debug = false;

# Shows the records in presidents
#function show_records($dbc) {
	# Create a query to get the number, first name, and last name sorted by number
#	$query = 'SELECT create_date, status, item FROM stuff';# ORDER BY create-date ASC' ;
#
	# Execute the query
#	$results = mysqli_query( $dbc , $query ) ;
#	check_results($results) ;
#
	# Show results
#	if( $results )
#	{
  		# But...wait until we know the query succeed before
  		# rendering the table start.
 # 		echo '<H1>Presidents</H1>' ;
  #		echo '<TABLE>';
  	#	echo '<TR>';
  	#	echo '<TH>Date/time</TH>';
  	#	echo '<TH>Status</TH>';
	#	echo '<TH>Stuff</TH>';
  	#	echo '</TR>';
#
  		# For each row result, generate a table row
 # 		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  #		{
   # 		echo '<TR>' ;
    #		echo '<TD>' . $row['create_date'] . '</TD>' ;
    #		echo '<TD>' . $row['status'] . '</TD>' ;
	#		echo '<TD>' . $row['item'] . '</TD>' ;
    #		echo '</TR>' ;
  	#	}
#
  		# End the table
 # 		echo '</TABLE>';
#
  		# Free up the results in memory
 # 		mysqli_free_result( $results ) ;
	#}
#}

# Shows the records within the last few days
function show_records_home($dbc, $days) {
	# Create a query to get the date item was lost/found, reported date, item status, item name, and id sorted by reported date
	$query = 'SELECT lostfound_date,create_date, status, item, id FROM stuff WHERE DATEDIFF(CURDATE(),create_date)<'.$days.' ORDER BY create_date DESC' ;

	# Execute the query
	$results = mysqli_query( $dbc , $query ) ;
	check_results($results) ;

	# Show results
	if( $results )
	{
  		# But...wait until we know the query succeed before
  		# rendering the table start.
  		echo '<TABLE>';
  		echo '<TR>';
  		echo '<TH>Date/time</TH>';
  		echo '<TH>Status</TH>';
		echo '<TH>Stuff</TH>';
  		echo '</TR>';

  		# For each row result, generate a table row
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
    		echo '<TR>' ;
    		echo '<TD>' . $row['lostfound_date'] . '</TD>' ;
    		echo '<TD>' . $row['status'] . '</TD>' ;
			$alink = '<A HREF=limbo-ql.php?id=' . $row['id'] . '>' . $row['item'] . '</A>'; #Make the row a link which users can click to see the rest of the details.
			echo '<TD>' . $alink .'</TD>'; #Create a row of the table using that link    		
			echo '</TR>' ;
  		}

  		# End the table
  		echo '</TABLE>';

  		# Free up the results in memory
  		mysqli_free_result( $results ) ;
	}
}

# Inserts a record into the stuff table with an owner 
function insert_lost_record($dbc, $name, $date, $area, $owner, $contact, $room, $contact2, $desc) {
  $query = 'INSERT INTO stuff(item,lostfound_date,create_date,location_id,owner,contact_info,room,contact_info2,description,status)
  VALUES ("'.$name.'","CURDATE()","'.$date.'","'.$area.'","'.$owner.'","'.$contact.'","'.$room.'","'.$contact2.'","'.$desc.'","lost")' ; #Adds all the values into the table
  show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}

# Inserts a record into the stuff table with a finder
function insert_found_record($dbc, $name, $date, $area, $finder, $contact, $room, $contact2, $desc) {
  $query = 'INSERT INTO stuff(item,lostfound_date,create_date,location_id,finder,contact_info,room,contact_info2,description,status)
  VALUES ("'.$name.'","CURDATE()","'.$date.'","'.$area.'","'.$finder.'","'.$contact.'","'.$room.'","'.$contact2.'","'.$desc.'","found")' ; #Adds all the values into the table
  show_query($query);

  $results = mysqli_query($dbc,$query) ;
  check_results($results) ;

  return $results ;
}

function show_record($dbc, $id) { #A modified version of show_records, changed to show details of only one row
	# Create a query to get the almost all information of an item from stuff
	$query = 'SELECT item,lostfound_date,create_date,location_id,owner,finder,contact_info,room,contact_info2,description,status FROM stuff WHERE id= ' . $id ;

	# Execute the query
	$results = mysqli_query( $dbc , $query ) ;
	check_results($results) ;

	# Show results
	if( $results )
	{
  		# But...wait until we know the query succeed before

  		# For each row result, generate a table row
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
			echo '<H1>'.$row['item'].'</H1>' ;
			if($row['status']=='lost'){
				echo '<H2>Item is currently lost</H2>' ;
			}
			else if($row['status']=='found'){
				echo '<H2>Item is currently lost</H2>' ;
			}
			else{
				echo '<H2>Item has been claimed by '.$row['owner'].'.</H2>' ;
			}
			echo '<TABLE>';
    		echo '<TR><TD>Description</TD><TD>' . $row['description'] . '</TD></TR>' ;
			$loc=mysqli_fetch_array(mysqli_query($dbc,'SELECT name FROM locations WHERE id='.$row['location_id']));
			if($row['status']=='found'){
				echo '<TR><TD>Found on</TD><TD>' . $row['lostfound_date'] . '</TD></TR>' ;
				echo '<TR><TD>Found by</TD><TD>' . $row['finder'] . '</TD></TR>' ;
				echo '<TR><TD>Lost at</TD><TD>' . $loc['name'] . '</TD></TR>' ;
				if(!empty($row['room']))
					echo '<TR><TD>Found in</TD><TD>' . $row['room'] . '</TD></TR>' ;
			}
			else{
				echo '<TR><TD>Lost on</TD><TD>' . $row['lostfound_date'] . '</TD></TR>' ;
				echo '<TR><TD>Lost by</TD><TD>' . $row['owner'] . '</TD></TR>' ;
				echo '<TR><TD>Lost at</TD><TD>' . $loc['name'] . '</TD></TR>' ;
				if(!empty($row['room']))
					echo '<TR><TD>Lost in</TD><TD>' . $row['room'] . '</TD></TR>' ;
				if(!empty($row['finder']))
					echo '<TR><TD>Found by</TD><TD>' . $row['finder'] . '</TD></TR>' ;
			}    		
    		echo '<TR><TD>Reported on</TD><TD>' . $row['create_date'] . '</TD></TR>' ;
    		echo '<TR><TD>Contact Line</TD><TD>' . $row['contact_info'] . '</TD></TR>' ;
			if(!empty($row['contact2']))
				echo '<TR><TD>Contact Line 2</TD><TD>' . $row['contact2'] . '</TD></TR>' ;
			
  		}
		
  		# End the table
  		echo '</TABLE>';
		



  		# Free up the results in memory
  		mysqli_free_result( $results ) ;
	}
}

# Shows the query as a debugging aid
function show_query($query) {
  global $debug;

  if($debug)
    echo "<p>Query = $query</p>" ;
}

# Checks the query results as a debugging aid
function check_results($results) {
  global $dbc;

  if($results != true)
    echo '<p>SQL ERROR = ' . mysqli_error( $dbc ) . '</p>'  ;
}

function get_all_locations($dbc) {
	# Create a query to get the date item was lost/found, reported date, item status, item name, and id sorted by reported date
	$query = 'SELECT name, id FROM locations ORDER BY id ASC' ;

	# Execute the query
	$results = mysqli_query( $dbc , $query ) ;
	check_results($results) ;

	# Show results
	if( $results )
	{
  		# For each row result, output a selection box choice
  		while ( $row = mysqli_fetch_array( $results , MYSQLI_ASSOC ) )
  		{
    		echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
  		}

  		# Free up the results in memory
  		mysqli_free_result( $results ) ;
	}
}
?>