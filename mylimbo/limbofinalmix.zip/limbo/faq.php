<!--The Frequently asked questions page
Created by Ryan Sheffler and Vincent Acocella
-->
<!DOCTYPE html>
<html>

<head> <!--Set up the page by grabbing the stylesheet and everything-->
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
    
  <!--Hover settings for the Marist map -->  
    <style>
.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f8f8f8;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    padding: 12px 16px;
    z-index: 1;
}
.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</head>
    
<body>
	<div class="nav"> <!--Make the ever-present navigation bar at the top of the screen-->
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
                <td><a href="faq.php">FAQ</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>
    <div class="main">
        <h1>Frequently Asked Questions</h1>
        <table table style="width:100%">
        <tr><td><h2> Q:  How will I know if my item was found?</h2></td>
        <td><h3> A:  Including contact information with your request will allow whoever finds your item (or us) to contact you.</h3></td></tr>
        <tr><td><h2>Q: I'm not familiar with Marist College. How do I know the name of the building I lost my item in. </h2></td>
            <td><h3>A:
                <div class="dropdown">
                <span style ="color:red">Mouse over for a map of Marist's campus</span>
                <div class="dropdown-content">
                <img src= "marist_map.jpg" alt="Marist" width="744" height= "601">
                </div></div>
                </h3></td></tr>
        </table>  
    </div>    
    </body>
</html>