<!--The limbo search page for all users to see search results and continue to search items
Created by Ryan Sheffler and Vincent Acocella
-->
<!DOCTYPE html>
<html>
<head> <!--Set up the page by grabbing the stylesheet and everything-->
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
</head>
<body>
	<div class="nav"> <!--Make the ever-present navigation bar at the top of the screen-->
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
                <td><a href="faq.php">FAQ</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>
	<div class="main"> <!--main is where all the text and stuff goes... the main part of the page-->
        
        
		<h1>Welcome to Limbo!</h1>
		<p>Search for your lost stuff</p>
        
        <form action= "limbo-landing-search.php" method="post">
        <input type="text" name="search" placeholder="Search">
        <input type="submit" value="Go">    
        </form>
        
        <?php   
           require( 'includes/connect_db.php' );
	       # Includes these helper functions
	       require( 'includes/helpers.php' );
        
		#If there's text in the search field, searches for item
		  if(isset($_POST['search']))
		  {
			$search = $_POST['search'];
			  
			#Run search_item 
			if(search_item($dbc , $search)==1)
				echo 'Success!';
			else{ #If nothing is found, print a search failed error message with all the items for reference
				echo 'No Results Found!';
				show_records_home($dbc,99999999);
			}
        }
        mysqli_close( $dbc ) ;
        ?>
		</div>
    </body>
</html>