#This file creates the Limbo database and adds tables for admins, lost and found items, and locations.
#In addition, adds an admin and all location names.
#Authors: Ryan Sheffler, Anthony Buzzell, Vincent Acocella
DROP database IF EXISTS limbo_db;
CREATE DATABASE limbo_db;
USE limbo_db;

#Create the users table, which holds all site admins
CREATE TABLE IF NOT EXISTS users(
	user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	username VARCHAR(20) NOT NULL,
	email VARCHAR(60) UNIQUE NOT NULL,
	pass CHAR(255) NOT NULL,
	reg_date DATETIME NOT NULL
);

#Create the stuff table, which will hold all information about lost and found items
CREATE TABLE stuff (
	id INT AUTO_INCREMENT PRIMARY KEY,
    item TEXT NOT NULL, 
	location_id INT NOT NULL,
	description TEXT,
	create_date DATETIME NOT NULL,
	lostfound_date DATE NOT NULL,
	update_date DATETIME,
	contact_info TEXT,
	contact_info2 TEXT,
	room TEXT,
	owner TEXT,
	finder TEXT,
	status SET('found', 'lost','claimed') NOT NULL
);

#Create the locations table, which holds the names of all buildings on campus
CREATE TABLE locations(
	id INT AUTO_INCREMENT PRIMARY KEY,
	create_date DATETIME NOT NULL,
	update_date DATETIME NOT NULL,
	name TEXT NOT NULL
);

#Add a default site admin to the users table (username: admin password: gaze11e)
INSERT INTO users(username,email,pass,reg_date)
VALUE('admin','someone@example.com','$2y$10$M8w4Xv.BOihL3XPO2mJuQetT60T6h5znTyWG2d0a0K1TGpStctnZO',Now());

#Add all building names to the locations table ~ Now in aLpHaBeTiCaL (yes i got made fun of in high school)
INSERT INTO locations(create_date,update_date,name)
VALUES (Now(),Now(),'Building C'),
(Now(),Now(),'Building D'),
(Now(),Now(),'Byrne House'),
(Now(),Now(),'Cannavino Library'),
(Now(),Now(),'Champagnat Hall'),
(Now(),Now(),'Chapel'),
(Now(),Now(),'Cornell Boathouse'),
(Now(),Now(),'Donnelly Hall'),
(Now(),Now(),'Dyson Center'),
(Now(),Now(),'Fern Tor'),
(Now(),Now(),'Fontaine Hall'),
(Now(),Now(),'Foy Townhouses'),
(Now(),Now(),'Greystone Hall'),
(Now(),Now(),'Hancock Center'),
(Now(),Now(),'Kieran Gatehouse'),
(Now(),Now(),'Kirk House'),
(Now(),Now(),'Lavelle Hall(Building B)'),
(Now(),Now(),'Leo Hall'),
(Now(),Now(),'Lowell Thomas'),
(Now(),Now(),'Lower Fulton Townhouses'),
(Now(),Now(),'Lower New Townhouses' ),
(Now(),Now(),'Lower West Townhouses'),
(Now(),Now(),'Marian Hall'),
(Now(),Now(),'Marist Boathouse'),
(Now(),Now(),'McCann Recreational Center'),
(Now(),Now(),'Mid-Rise Hall'),
(Now(),Now(),'Science and Allied Health Building'),
(Now(),Now(),'Sheahan Hall'),
(Now(),Now(),'St. Ann\'s Hermitage'),
(Now(),Now(),'St. Peter\'s'),
(Now(),Now(),'Steel Plant Studios and Gallery'),
(Now(),Now(),'Student Center'),
(Now(),Now(),'Upper Fulton Townhouses'),
(Now(),Now(),'Upper West Townhouses'),
(Now(),Now(),'Ward Hall(Building A)');

#Add some demo data to the stuff table
INSERT INTO stuff(item,location_id, description, create_date, lostfound_date, contact_info, room,owner, finder, STATUS)
VALUES 
("Marist ID", 1, "I left my Marist ID on the table by the fireplace.", '2018-11-05 20:14:07', '2018-11-06 10:56:02', '(xxx-)xxx-xxxx', "Lobby", "Bob Fox", "", 'lost'),

("Communications Textbook", 4, "I left my book in a lower New townhouse when working on a project but can not remember what house.", '2018-11-222 16:43:01', '2018-11-20 22:13:09', '(xxx-)xxx-xxxx', "", "Sarah Cap", "No Finder", 'lost'),

("Iphone Headsets", 9, "I was eating in the Building D dining hall and I forgot to bring my earphones along with me", '2018-11-24 14:23:10', '2018-11-15 22:45:02', '(xxx-)xxx-xxxx', "main dining area", "Paul Blart", "", 'lost'),

("Marist Water bottle", 11 , "I found a Marist water bottle in my class that does not belong to anyone here currently.", '2018-11-01 14:12:10' ,'2018-11-04 09:10:45', '(xxx-)xxx-xxxx', "2nd floor study room 3016", "", "Steve Smith", 'found'),

("Room Keys", 14 , "A set of room keys were found on the floor in Donnelly Hall.", '2018-11-09 23:09:45', '2018-11-10 20:28:11', '(xxx-)xxx-xxxx', "Main Hallway", "", "Billy Bob", 'found'),

("USB Drive" , 17 , "A USB with a name on it was found in the bathroom of Fountain Hall.", '2018-11-01 09:15:06', '2018-11-02 10:43:22', '(xxx-)xxx-xxxx', "Bathroom", "Michael Booster", "Stacy Moon", 'found'),

("The Space Race" , 8 , "Союз нерушимый республик свободных" , '2018-11-27 03:10:12' , '1969-07-20 22:34:22' , '(xxx-)xxx-xxxx' , "Moon", "Leonid Brezhnev", "No Finder" , 'lost'),

("Gary" , 2 , "Gary come home you're my best friend" , '2018-11-18 06:01:02' , '2018-11-20 01-02-03', '(xxx-)xxx-xxxx', "Bikini Bottom", "Bob Square-pants", "No Finder", 'lost'),

("Waldo", 10, "He was in the corner by the clown next to the dog with the hat", '2018-11-01 02:05:09' ,'2018-11-20 22:13:09', '(xxx-)xxx-xxxx', "", "" ,  "Bill Belly", 'found'),

("Laptop", 1 , "I found a laptop in class", '2018-11-22 17:20:05', '2018-11-26 20:19:18', '(xxx-)xxx-xxxx', "Hancock 0004", "", "Stacy Tracy", 'found'),

("Whisper", 14, "FOUR", '2018-11-30 03:29:34', '2018-11-30 3:00:00', 'marc.merrill@hotmail.com', "Marist eSports Room","Jhin","",'lost'),

("Monika daki", 12, "please i need it to sleep tim stole it please he won't stop saying delete", '2018-11-29 21:01:56', '2018-11-29 21:00:00', 'limbo.programmerspaddle.com', "B3", "William Kluge", "", 'lost'); #he will never get it back.

select * FROM stuff;






