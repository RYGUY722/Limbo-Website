<!--[UNUSED]
A page where users can mail their questions to an admin
Created by Ryan Sheffler and Vincent Acocella
-->
<!DOCTYPE html>
<html>
<head> <!--Set up the page by grabbing the stylesheet and everything-->
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
</head>
<body>
	<div class="nav"> <!--Make the ever-present navigation bar at the top of the screen-->
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
                <td><a href="faq.php">FAQ</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>
	<div class="main"> <!--main is where all the text and stuff goes... the main part of the page-->
        
        <?php
        
        require( 'includes/connect_db.php' );
	   # Includes these helper functions
	   require( 'includes/helpers.php' );
        
        
        if($_SERVER["REQUEST_METHOD"] == "POST")
            
            $name = check_data('name');
            $topic = check_data('topic');
            $message = check_data('message');
        
        send_question($name, $topic , $message);
        
        
        
        ?>
    
        <h1>Have a Question?</h1>
        
        <form action="question_to_admin.php" method="post">
        Name: <input type="text" name="name"><br>
        Topic: <input type="text" name="topic"><br>
        Message: <textarea name="message" rows="6" cols="50"></textarea><br>
        <input type="submit">
        </form>
    </div>