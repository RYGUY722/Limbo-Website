<!--[UNUSED] this didn't get very far
A page where users can customize their search to find exactly what they want
Created by Ryan Sheffler and Vincent Acocella
-->
<!DOCTYPE html>
<html>
<head> <!--Set up the page by grabbing the stylesheet and everything-->
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
</head>
<body>
	<div class="nav"> <!--Make the ever-present navigation bar at the top of the screen-->
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>

    
		<form action="advanced_search.php" method="POST">
		<select name="AD_search" > <!--Create a dropdown menu to choose how long ago you want results from-->
			<option >7 days</option>
			<option value="14">14 days</option>
			<option value="30">30 days</option>
			<option value="99999999">All time</option>
		</select>
		<input type="submit" >
		</form>     
		<?php
	require( 'includes/connect_db.php' );
	# Includes these helper functions
	require( 'includes/helpers.php' );
    
    
    
    
</body>
</html>