<!--The first page a user should see upon entering the limbo site
Created by Ryan Sheffler, Vincent Acocella, and Anthony Buzzell
-->
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
</head>
<body>
	<div class="nav">
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>
	<div class="main">		
		<?php
			require( 'includes/connect_db.php' );
			# Includes these helper functions
			require( 'includes/helpers.php' );
			
			# Show the records
			if($_SERVER['REQUEST_METHOD'] == 'GET')
				if(isset($_GET['id']))
					show_record($dbc, $_GET['id']);
			else
				echo '<h1>An error has occurred. Please go back to the homepage and retry.</h1>';

			# Close the connection
			mysqli_close( $dbc ) ;
		?>
	</div>
</body>

</html>