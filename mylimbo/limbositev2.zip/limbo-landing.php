<!--The first page a user should see upon entering the limbo site
Created by Ryan Sheffler, Vincent Acocella, and Anthony Buzzell
-->
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
</head>
<body>
	<div class="nav">
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>
	<div class="main">
		<h1>Welcome to Limbo!</h1>
		<p>If you've lost or found something, you're in luck: this is the place to report it.</p>
		<h2>Reported in the last </h2>
		<form action="limbo-landing.php" method="POST">
		<select name="dayform" >
			<option value="7">7 days</option>
			<option value="14">14 days</option>
			<option value="30">30 days</option>
			<option value="99999999">All time</option>
		</select>
		<input type="submit" >
		</form>
		<?php
	require( 'includes/connect_db.php' );
	# Includes these helper functions
	require( 'includes/helpers.php' );
	
	# Show the records
	if($_SERVER['REQUEST_METHOD'] == 'POST')
		show_records_home($dbc, $_POST['dayform']);
	else
		show_records_home($dbc,7);

	# Close the connection
	mysqli_close( $dbc ) ;
?>
	</div>
</body>

</html>