<!--The first page a user should see upon entering the limbo site
Created by Ryan Sheffler, Vincent Acocella, and Anthony Buzzell
-->
<!DOCTYPE html>
<html>
<head>
		<meta charset="utf-8">
		<title>Limbo</title>
		<link rel="stylesheet" type="text/css" href="limbo.css">
</head>
		<?php
	require( 'includes/connect_db.php' );
	# Includes these helper functions
	require( 'includes/helpers.php' );
	
	#Only allow the user to add items if all fields are filled
	if ($_SERVER[ 'REQUEST_METHOD' ] == 'POST') {
		$room=$_POST['room'];
		$contact2=$_POST['room'];
		$desc=$_POST['room'];
		$errors = array(); #New error catcher uses an array

		if(empty($_POST['name'])) #Test if item name is invalid
			$errors[] = 'item name';
		else #If not, prep name
			$name = trim($_POST['name']);
			
		if(empty($_POST['date'])) #Test if lost date is invalid
			$errors[] = 'lost date';
		else #If not, prep date
			$date = trim($_POST['date']);
			
		if(empty($_POST['area'])) #Test if building/area is invalid
			$errors[] = 'building/area';
		else #If not, prep area
			$area = trim($_POST['area']);
			
		if(empty($_POST['finder'])) #Test if finder name is invalid
			$errors[] = 'your name';
		else #If not, prep owner
			$finder = trim($_POST['finder']);
			
		if(empty($_POST['contact'])) #Test if contact info is invalid
			$errors[] = 'contact info';
		else #If not, prep contact
			$contact = trim($_POST['contact']);
			
		#if(!empty($_POST['room'])
		#	$room=$_POST['room'];
		
		#if(!empty($_POST['contact2'])
		#	$contact2=$_POST['contact2'];
		
		#if(!empty($_POST['desc'])
		#	$desc=$_POST['desc'];
			
		if( !empty( $errors ) ){ #Check for errors and report them
			echo 'An error has occurred. Please check the  ' ;
			foreach ( $errors as $msg ) { echo " - $msg " ; }
		}
		else{ #Otherwise, pass the values through
			$result = insert_found_record($dbc, $name, $date, $area, $finder, $contact, $room, $contact2, $desc) ;

			echo "<p>Success, thank you for submitting!</p>" ;
		}
	}

	# Close the connection
	mysqli_close( $dbc ) ;
?>
<body>
	<div class="nav">
		<table>
			<tr>
				<td><a href="limbo-landing.php"><img src="fox.png" title="Back to Homepage" height="80" width="80"></a></td>
				<td><a href="limbo-lost.php">Lost Something?</a></td>
				<td><a href="limbo-found.php">Found Something?</a></td>
				<td><a href="limbo-admin.php">Admins</a></td>
			</tr>
		</table>
	</div>
	<div class="main">
		<h1>Found something?</h1>
		<p>Someone probably lost it. Give us some information and we can get it back to its owner.</p>
		<form action="limbo-lost.php" method="POST">
			<table>
			<tr>
			<td>Item Name:</td><td><input type="text" name="name" value="<?php if (isset($_POST['name'])) echo $_POST['name']; ?>"></td><td>*</td>
			</tr>
			<tr>
			<td>Approximate Date Found:</td><td><input type="date" name="date" value="<?php if (isset($_POST['date'])) echo $_POST['date']; ?>"></td><td>*</td>
			</tr>
			<tr>
			<td>Building/Area:</td> <td>
				<select name="area" >
					<option value="">Choose one...</option>
					<option value="1">Hancock Center</option>
					<option value="2">Champagnat Hall</option>
					<option value="3">Leo Hall</option>
					<option value="4">Lower New Townhouses</option>
					<option value="5">Foy Townhouses</option>
					<option value="6">Lavelle Hall(Building B)</option>
					<option value="7">Ward Hall(Building A)</option>
					<option value="8">Building C</option>
					<option value="9">Building D</option>
					<option value="10">Byrne House</option>
					<option value="11">Cannavino Library</option>
					<option value="12">Chapel</option>
					<option value="13">Cornell Boathouse</option>
					<option value="14">Donnelly Hall</option>
					<option value="15">Dyson Center</option>
					<option value="16">Fern Tor</option>
					<option value="17">Fontaine Hall</option>
					<option value="18">Lower Fulton Townhouses</option>
					<option value="19">Upper Fulton Townhouses</option>
					<option value="20">Greystone Hall</option>
					<option value="21">Kieran Gatehouse</option>
					<option value="22">Kirk House</option>
					<option value="23">Lowell Thomas</option>
					<option value="24">Marian Hall</option>
					<option value="25">Marist Boathouse</option>
					<option value="26">McCann Recreational Center</option>
					<option value="27">Mid-Rise Hall</option>
					<option value="28">St. Ann's Hermitage</option>
					<option value="29">St. Peter's</option>
					<option value="30">Sheahan Hall</option>
					<option value="31">Science and Allied Health Building</option>
					<option value="32">Steel Plant Studios and Gallery</option>
					<option value="33">Student Center</option>
					<option value="34">Upper West Townhouses</option>
					<option value="35">Lower West Townhouses</option>
				</select>
			</td><td>*</td>
			</tr>
			<tr>
			<td>Room:</td><td><input type="text" name="room" value="<?php if (isset($_POST['room'])) echo $_POST['room']; ?>"></td>
			</tr>
			<tr>
			<td>Your Name:</td><td><input type="text" name="owner" value="<?php if (isset($_POST['owner'])) echo $_POST['owner']; ?>"></td><td>*</td>
			</tr>
			<tr>
			<td>Contact Info:</td><td><input type="text" name="contact" value="<?php if (isset($_POST['contact'])) echo $_POST['contact']; ?>"></td><td>*</td>
			</tr>
			<tr>
			<td>Secondary Contact Info:</td><td><input type="text" name="contact2" value="<?php if (isset($_POST['contact2'])) echo $_POST['contact2']; ?>"></td>
			</tr>
			<tr>
			<td>Description:</td><td><input type="textarea" name="desc" value="<?php if (isset($_POST['desc'])) echo $_POST['desc']; ?>"></td>
			</tr>
			</table>
		<p>*=Information is required.</p>
		<input type="submit" >
		</form>
	</div>
</body>

</html>